# -*- coding: utf-8 -*-
{
    'name': "Prueba",
    'application': True,
    'summary': """
        Modulo de prueba """,

    'description': """

    """,

    'author': "Ricardo Brenes",
    'website': "https://www.coromuni.go.cr",

    'category': 'P.D.I.',
    'version': '16.0.1.0.0',

    'depends': [
    ],

    'data': [
        'security/groups.xml',
        'security/ir.model.access.csv',
        'data/menu_data.xml',
    ]
}
